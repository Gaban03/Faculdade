package exercicios;

/* Vinicius Brolezzi Gaban */

public class Exercicio_01 {

	/* 1. Imprima todos os números de 150 a 300. */

	public static void main(String[] args) {

		for (int i = 150; i <= 300; i++) {
			System.out.println("Contador: " + i);
		}

	}

}
