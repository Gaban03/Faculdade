package exer4;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ArrayList<Produto> produtos = new ArrayList<>();

        System.out.print("Digite o número de produtos: ");
        int numeroDeProdutos = scanner.nextInt();

        for (int i = 0; i < numeroDeProdutos; i++) {
            System.out.println("Produto #" + (i + 1) + " dados:");
            System.out.print("Produto comum, usado ou importado (c/u/i)? ");
            String tipoEntrada = scanner.next(); 

            String tipo = tipoEntrada.toLowerCase();  

            System.out.print("Nome: ");
            scanner.nextLine();  
            String nome = scanner.nextLine();
            System.out.print("Preço: ");
            double preco = scanner.nextDouble();

            if (tipo.equals("c")) {
                produtos.add(new Produto(nome, preco));

            } else if (tipo.equals("u")) {
                System.out.print("Data de fabricação (DD/MM/YYYY): ");
                scanner.nextLine();  
                String dataFabricacao = scanner.nextLine();
                produtos.add(new ProdutoUsado(nome, preco, dataFabricacao));

            } else if (tipo.equals("i")) {
                System.out.print("Taxa de alfândega: ");
                double taxaAlfandega = scanner.nextDouble();
                produtos.add(new ProdutoImportado(nome, preco, taxaAlfandega));
            }
        }

        System.out.println();
        System.out.println("ETIQUETAS DE PREÇO:");
        for (Produto p : produtos) {
            p.exibirEtiqueta();  
        }

        scanner.close();
    }
}
