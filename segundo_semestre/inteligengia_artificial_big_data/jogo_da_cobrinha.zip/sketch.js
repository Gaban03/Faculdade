let x = 40;
let y = 40;
let size = 20;
let speed = 3;
let direction = "idle"

// Classifier Variable
let classifier;
let comando = "idle";
// Model URL
let imageModelURL = "https://teachablemachine.withgoogle.com/models/7Tj9rphai/";

// Video
let video;
// To store the classification
let label = "";

let xFood;
let yFood;

// Load the model first
function preload() {
  classifier = ml5.imageClassifier(imageModelURL + "model.json");
  console.log(classifier)
}

function setup() {
  createCanvas(400, 400);
  //Ponto aparecer em um lugar aleátorio
  xFood = floor(random(20,380))
  yFood = floor(random(20,380))
  
  frameRate(20)
  video = createCapture(VIDEO);
  video.size(320, 240);
  video.hide();

  // Start classifying
  classifyVideo();
}

function draw() {
  background(0);
  
  //Cobra
  square(x,y,size);
  if(direction === 'Cima') y = y - speed
  if(direction === 'Baixo') y = y + speed
  if(direction === 'Direita') x = x + speed
  if(direction === 'Esquerda') x = x - speed
  
  //Comida
  square(xFood, yFood, 10);
  distance = dist(x,y, xFood, yFood);
  if (distance < 20){
    size = size + 2;
    spawn();
  }
  
   // Draw the video
  //image(video, 0, 0);
  text(comando, 50,50);
  
  // Draw the label
  fill(255);
  textSize(16);
  textAlign(CENTER);
  text(label, width / 2, height - 4);
  
  // Start classifying
  classifyVideo();
}

//Spawn da comida
function spawn(){
  xFood = floor(random(20,380))
  yFood = floor(random(20,380))
}

function keyPressed(){
  direction = key;
  
}

function classifyVideo() {
  flippedVideo = ml5.flipImage(video)
  classifier.classify(flippedVideo, gotResult);
  
}

function gotResult(error, results) {
  direction = results[0].label;
}

