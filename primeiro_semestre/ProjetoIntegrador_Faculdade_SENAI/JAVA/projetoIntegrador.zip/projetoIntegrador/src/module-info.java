/**
 * 
 */
/**
 * 
 */
module projetoIntegrador {
	requires java.desktop;
}