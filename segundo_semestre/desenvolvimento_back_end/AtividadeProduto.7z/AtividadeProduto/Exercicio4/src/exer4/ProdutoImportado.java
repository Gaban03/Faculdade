package exer4;

public class ProdutoImportado extends Produto {

    private Double taxaDeAlfandega;

    public ProdutoImportado() {}

    public ProdutoImportado(String nome, Double preco, Double taxaDeAlfandega) {
        super(nome, preco);
        this.taxaDeAlfandega = taxaDeAlfandega;
    }

    public Double getTaxaDeAlfandega() {
        return taxaDeAlfandega;
    }

    public void setTaxaDeAlfandega(Double taxaDeAlfandega) {
        this.taxaDeAlfandega = taxaDeAlfandega;
    }

    @Override
    public void exibirEtiqueta() {
        double precoFinal = getPreco() + taxaDeAlfandega;
        System.out.printf("%s $ %.2f (Taxa de alfândega: $ %.2f)%n", getNome(), precoFinal, taxaDeAlfandega);
    }
}
