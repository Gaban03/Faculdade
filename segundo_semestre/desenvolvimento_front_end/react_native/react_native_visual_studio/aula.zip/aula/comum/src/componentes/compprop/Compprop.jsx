function Compprop(props){
    return(
        <div>
            <hr />
            <br />
            <h2>Testando Compprop</h2>
            <p> O meu nome é {props.nome}</p>
        </div>
    )
}export default Compprop