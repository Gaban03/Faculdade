package exer4;

public class ProdutoUsado extends Produto {

    private String dataDeFabricacao;

    public ProdutoUsado() {}

    public ProdutoUsado(String nome, Double preco, String dataDeFabricacao) {
        super(nome, preco);
        this.dataDeFabricacao = dataDeFabricacao;
    }

    public String getDataDeFabricacao() {
        return dataDeFabricacao;
    }

    public void setDataDeFabricacao(String dataDeFabricacao) {
        this.dataDeFabricacao = dataDeFabricacao;
    }

    @Override
    public void exibirEtiqueta() {
        System.out.printf("%s (usado) $ %.2f (Data de fabricação: %s)%n", getNome(), getPreco(), dataDeFabricacao);
    }
}
